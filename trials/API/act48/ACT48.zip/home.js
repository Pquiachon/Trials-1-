$(document).ready(function (x) {
  let loggedIn = localStorage.getItem("loggedIn");

  if (loggedIn == 0) window.location.href = "home.html";

  $("#logout").click(function () {
    localStorage.setItem("loggedIn", 0);
    x.preventDefault();
  });
});
