$(document).ready(function () {
    $("#welcome").click(function () {
        alert("Welcome to CAE College!");
    });
});
