<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="css/styles.css"/>
    <script src="js/message.js"></script>
    <title>Home</title>
</head>
<body>
    <?php echo $__env->make('layouts/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Home Page</h1>
    <img src="img/college.jpg" class="img-fluid" alt="students posing"/>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Provident ipsam amet animi quam soluta ratione tempore aspernatur voluptates ad itaque.</p>
    <button id="welcome" class="btn btn-primary">Greet</button>
</body>
</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/home.blade.php ENDPATH**/ ?>