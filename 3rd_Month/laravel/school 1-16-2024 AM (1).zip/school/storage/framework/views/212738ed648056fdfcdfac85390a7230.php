<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Show Student</title>
</head>
<body>
    <?php echo $__env->make('layouts/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Student ID: <?php echo e($student -> student_id); ?></h1>
    <h2>Personal information</h2>
    <ul>
        <li>Full name: <?php echo e($student -> last_name); ?>, <?php echo e($student -> first_name); ?></li>
        <li>Birthdate: <?php echo e(date_format($student -> birthdate, 'Y-m-d')); ?></li>
        <li>Gender: <?php echo e($student -> gender); ?></li>
        <li>Province: <?php echo e($student -> province); ?></li>
    </ul>
    <h2>Enrollment information</h2>
    <ul>
        <li>Year level: <?php echo e($student -> year_level); ?></li>
        <li>Date enrolled: <?php echo e(date_format($student -> date_enrolled, 'Y-m-d')); ?></li>
    </ul>
    <h2>Contact information</h2>
    <ul>
        <li>Mobile number: <?php echo e($student -> mobile_number); ?></li>
        <li>Email address: <?php echo e($student -> email_address); ?></li>
</body>
</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/student_show.blade.php ENDPATH**/ ?>