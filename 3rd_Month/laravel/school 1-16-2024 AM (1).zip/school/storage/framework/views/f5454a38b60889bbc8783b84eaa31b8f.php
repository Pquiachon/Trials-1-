<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Add New Faculty</title>
</head>

<body>
    <?php echo $__env->make('layouts/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Add New Faculty</h1>
    <form action="/faculties/<?php echo e($faculty -> faculty_id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label>First name:</label>
        <input type="text" name="first_name" value="<?php echo e($faculty -> first_name); ?>" /><br />
        <label>Last name:</label>
        <input type="text" name="last_name" value="<?php echo e($faculty -> last_name); ?>"/><br />
        <label>Birthdate:</label>
        <input type="date" name="birthdate" value="<?php echo e(date_format($faculty -> birthdate, 'Y-m-d')); ?>" /><br />
        <label>Gender:</label>
        <select name="gender">
        <option value="<?php echo e($faculty -> gender); ?>"><?php echo e($faculty -> gender); ?></option>
            <option disabled>-----------</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
        </select><br />
        <label>Mobile number:</label>
        <input type="text" name="mobile_number" value="<?php echo e($faculty -> mobile_number); ?>"/><br />
        <label>Email address:</label>
        <input type="email" name="email_address" value="<?php echo e($faculty -> email_address); ?>"/><br />
        <label>Position:</label>
        <select name="position">
            <option value="<?php echo e($faculty -> position); ?>"><?php echo e($faculty -> position); ?></option>
            <option disabled>-----------</option>
            <option value="Lecturer 1">Lecturer 1</option>
            <option value="Lecturer 2">Lecturer 2</option>
            <option value="Professor 1">Professor 1</option>
            <option value="Professor 2">Professor 2</option>
        </select><br />
        <label>Department:</label>
        <select name="department">
            <option value="<?php echo e($faculty -> department); ?>"><?php echo e($faculty -> department); ?></option>
            <option disabled>-----------</option>
            <option value="Computer">Computer</option>
            <option value="Science">Science</option>
            <option value="Social Science">Social Science</option>
            <option value="Filipino">Filipino</option>
            <option value="History">History</option>
            <option value="MAPEH">MAPEH</option>
            <option value="Mathematics">Mathematics</option>
            <option value="English">English</option>
        </select><br />
        <input type="submit" class="btn btn-success">
    </form>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/faculty_edit.blade.php ENDPATH**/ ?>