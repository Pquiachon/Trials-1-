<?php if(Session::get('role') == 'admin'): ?>
    <?php echo $__env->make('layouts/navbar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('layouts/navbar_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>