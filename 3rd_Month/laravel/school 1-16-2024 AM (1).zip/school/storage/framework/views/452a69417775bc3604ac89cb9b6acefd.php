<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Classes</title>
</head>
<body>
    <?php echo $__env->make('layouts/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Classes per department</h1>
    <table class="table">
        <tr>
            <th>Department</th>
            <th>Number of classes</th>
        </tr>
    <?php $__currentLoopData = $classes_dept; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($cd -> department); ?></td>
            <td><?php echo e($cd -> total_classes); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <h1>All Classes</h1>
    <table class="table">
        <tr>
            <th>Class ID</th>
            <th>Schedule</th>
            <th>Room</th>
            <th>Subject name</th>
        </tr>
    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($c -> class_id); ?></td>
            <td><?php echo e($c -> schedule); ?></td>
            <td><?php echo e($c -> room); ?></td>
            <td><?php echo e($c -> name); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/class.blade.php ENDPATH**/ ?>