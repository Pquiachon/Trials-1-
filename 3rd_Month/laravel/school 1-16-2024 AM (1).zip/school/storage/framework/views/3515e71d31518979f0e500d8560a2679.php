<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Faculties</title>
</head>
<body>
    <?php echo $__env->make('layouts/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Faculties List</h1>
    <a href="faculties/create" class="btn btn-success">+ Add</a>
    <table class="table">
        <tr>
            <th>Name</th>
            <th>Depatment</th>
            <th>Faculty ID</th>
            <th>View Entry</th>
            <th>Edit Entry</th>
            <th>Delete Entry</th>
        </tr>
        <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($f -> last_name); ?>, <?php echo e($f -> first_name); ?></td>
            <td><?php echo e($f -> department); ?></td>
            <td><?php echo e($f -> faculty_id); ?></td>
            <td><a href="/faculties/<?php echo e($f -> faculty_id); ?>" class="btn btn-primary">View</a></td>
            <td><a href="/faculties/edit/<?php echo e($f -> faculty_id); ?>" class="btn btn-warning">Edit</a></td>
            <td>
                <form action="/faculties/<?php echo e($f -> faculty_id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <input type="submit" class="btn btn-danger" value="Delete"/>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <h1>Faculties Data</h1>
    <h2>Department</h2>
    <table class="table">
        <tr>
            <th>Department</th>
            <th>Total Faculty</th>
        </tr>
        <?php $__currentLoopData = $faculties_dept; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($fd -> department); ?></td>
            <td><?php echo e($fd -> total_faculty); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <h2>Promotions</h2>
    <table class="table">
        <tr>
            <th>Name</th>
            <th>Academe Points</th>
        </tr>
        <?php $__currentLoopData = $faculties_points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($fp -> last_name); ?>, <?php echo e($fp -> first_name); ?> <?php echo e($fp -> last_name . ", " . $fp -> first_name); ?></td>
            <td><?php echo e($fp -> academe_points); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/faculty.blade.php ENDPATH**/ ?>