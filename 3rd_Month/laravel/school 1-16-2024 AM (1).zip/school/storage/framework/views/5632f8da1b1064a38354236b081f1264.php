<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Show Faculty</title>
</head>
<body>
    <?php echo $__env->make('layouts/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Faculty ID: <?php echo e($faculty -> faculty_id); ?></h1>
    <h2>Personal information</h2>
    <ul>
        <li>Full name: <?php echo e($faculty -> last_name); ?>, <?php echo e($faculty -> first_name); ?></li>
        <li>Birthdate: <?php echo e(date_format($faculty -> birthdate, 'Y-m-d')); ?></li>
        <li>Gender: <?php echo e($faculty -> gender); ?></li>
    </ul>
    <h2>Employment information</h2>
    <ul>
        <li>Position: <?php echo e($faculty -> position); ?></li>
        <li>Department: <?php echo e($faculty -> department); ?></li>
        <li>Date entered: <?php echo e(date_format($faculty -> date_entered, 'Y-m-d')); ?></li>
    </ul>
    <h2>Contact information</h2>
    <ul>
        <li>Mobile number: <?php echo e($faculty -> mobile_number); ?></li>
        <li>Email address: <?php echo e($faculty -> email_address); ?></li>
</body>
</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/faculty_show.blade.php ENDPATH**/ ?>