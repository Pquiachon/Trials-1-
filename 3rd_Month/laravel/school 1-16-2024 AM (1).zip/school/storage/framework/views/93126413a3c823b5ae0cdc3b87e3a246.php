<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="css/styles.css"/>
    <title>Students</title>
</head>
<body>
    <?php echo $__env->make('layouts/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Students</h1>
    <p>Total students: <?php echo e($total_student -> total); ?> <a href="/admin/students/create" class="btn btn-success"> + Add </a> </p>
    <table class="table">
        <tr>
            <th>First name</th>
            <th>Last name</th>
            <th>Year level</th>
            <th>Province</th>
            <th>More Info</th>
            <th>Edit Entry</th>
            <th>Delete Entry</th>
        </tr>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($s -> first_name); ?></td>
            <td><?php echo e($s -> last_name); ?></td>
            <td><?php echo e($s -> year_level); ?></td>
            <td><?php echo e($s -> province); ?></td>
            <td><a href="/admin/students/<?php echo e($s -> student_id); ?>" class="btn btn-primary">View</a></td>
            <td><a href="/admin/students/edit/<?php echo e($s -> student_id); ?>" class="btn btn-warning">Edit</a></td>
            <td>
                <a data-bs-toggle="modal" data-bs-target="#delete_<?php echo e($s -> student_id); ?>" class="btn btn-danger">Delete</a>
            </td>

            <div class="modal fade" id="delete_<?php echo e($s -> student_id); ?>" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Delete <?php echo e($s -> last_name); ?>, <?php echo e($s->first_name); ?>? (<?php echo e($s -> student_id); ?>)</h5>
                            <button class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">Once this action is taken, it cannot be undone.
                        <div class="modal-footer">
                            <button class="btn btn-secondary" data-bs-dismiss="modal">
                            Cancel
                            </button>
                            <form action="/admin/students/<?php echo e($s -> student_id); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input class="btn btn-danger" type="submit" value="Delete"/>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <h2>Male students:</h2>
    <table class="table">
        <tr>
            <th>First name</th>
            <th>Last name</th>
            <th>Gender</th>
            <th>Province</th>
        </tr>
        <?php $__currentLoopData = $students_male; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($sm -> first_name); ?></td>
            <td><?php echo e($sm -> last_name); ?></td>
            <td><?php echo e($sm -> gender); ?></td>
            <td><?php echo e($sm -> province); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/student.blade.php ENDPATH**/ ?>