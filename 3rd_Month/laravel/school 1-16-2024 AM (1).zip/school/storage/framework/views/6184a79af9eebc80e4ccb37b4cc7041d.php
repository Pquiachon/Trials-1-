<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Home</title>
</head>
<body>
    <?php echo $__env->make('layouts/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Subjects</h1>
    <table class="table">
        <tr>
            <th>Subject ID</th>
            <th>Subject Name</th>
            <th>Department</th>
        </tr>
        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($s -> subject_id); ?></td>
            <td><?php echo e($s -> name); ?></td>
            <td><?php echo e($s -> department); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/subject.blade.php ENDPATH**/ ?>